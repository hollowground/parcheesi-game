import { GameState } from "../types/GameState"
import { Move } from "../types/Move"
import { getLegalMoves } from "./getLegalMoves"
import { applyMove } from "./applyMove"
import { endTurn } from "../engine/endTurn"
import { checkWinner } from "./checkWinner"

export function playTurn(
    state: GameState,
    chooseMove: (moves: Move[], state: GameState) => Move
): GameState {

    let currentState = structuredClone(state)
    const isDoubles =
        currentState.dice.length === 2 &&
        currentState.dice[0] === currentState.dice[1]
    console.log(`Player ${currentState.currentPlayer} rolled: ${currentState.dice.join(", ")}${isDoubles ? " (DOUBLES!)" : ""}`)
    if (isDoubles) {
        currentState.consecutiveDoubles += 1
    } else {
        currentState.consecutiveDoubles = 0
    }

    if (currentState.consecutiveDoubles === 3) {

        const playerPawns = currentState.pawns.filter(
            p => p.player === currentState.currentPlayer
        )

        const farthest = playerPawns.reduce((a, b) => {
            if (a.position.type !== "track") return b
            if (b.position.type !== "track") return a
            return b.position.index > a.position.index ? b : a
        })

        if (farthest.position.type === "track") {
            farthest.position = { type: "start" }
        }

        currentState.consecutiveDoubles = 0

        return endTurn(currentState)
    }
    console.log("Starting turn for player:", currentState.currentPlayer)
    console.log("Bonus moves:", currentState.bonusMoves.join(", "))

    // -------------------------
    // PHASE 1: USE ALL DICE
    // -------------------------
    while (currentState.dice.length > 0) {

        const moves = getLegalMoves(currentState)
        console.log(`Legal moves available for dice: ${moves.length}`)
        if (moves.length === 0 && currentState.bonusMoves.length === 0) break

        // Only allow moves that use dice
        const diceMoves = moves.filter(m => currentState.dice.includes(m.die!))
        console.log(`Moves available for dice: ${JSON.stringify(diceMoves)}`)

        if (diceMoves.length === 0) break

        const move = chooseMove(diceMoves, currentState)
        console.log(`Chosen move:`, move)

        currentState = applyMove(currentState, move)
    }

    // -------------------------
    // PHASE 2: USE BONUS (ONCE PER BONUS)
    // -------------------------
    while (currentState.bonusMoves.length > 0) {

        const moves = getLegalMoves(currentState)
        //console.log(`Legal moves available for bonus: ${moves.length}`)
        //if (moves.length === 0) return endTurn(currentState)

        const bonusMoves = moves.filter(m => currentState.bonusMoves.includes(m.die!))
        //console.log(`Bonus moves available: ${bonusMoves.length}`)

        if (bonusMoves.length === 0) {
            // ❗ FORFEIT remaining bonuses
            currentState.bonusMoves = []
            break
        }

        const move = chooseMove(bonusMoves, currentState)

        currentState = applyMove(currentState, move)

        // 🔑 CRITICAL: consume ONE bonus explicitly
        //currentState.bonusMoves.shift()
    }

    // ✅ Check winner
    const winner = checkWinner(currentState)

    if (winner) {
        return {
            ...currentState,
            winner
        }
    }

    // ✅ If doubles → same player continues
    if (isDoubles) {
        return currentState
    }

    // ✅ Otherwise → end turn normally
    return endTurn(currentState)
}