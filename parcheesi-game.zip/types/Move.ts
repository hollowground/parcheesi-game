import { Position } from './GameState'

export interface Move {
    pawnId: number
    die: number
    dieIndex: number

    from: Position
    to: Position

    capture?: boolean
    enterFromStart?: boolean
    finish?: boolean
}